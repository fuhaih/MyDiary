# T3考题

## HTML

- HTML5的离线储存怎么使用，工作原理能不能解释一下？

```doc
  在用户没有与因特网连接时，可以正常访问站点或应用，在用户与因特网连接时，更新用户机器上的缓存文件。
  原理：HTML5的离线存储是基于一个新建的.appcache文件的缓存机制(不是存储技术)，通过这个文件上的解析清单离线存储资源，这些资源就会像cookie一样被存储了下来。之后当网络在处于离线状态下时，浏览器会通过被离线存储的数据进行页面展示。


  如何使用：
  1、页面头部像下面一样加入一个manifest的属性；
  2、在cache.manifest文件的编写离线存储的资源；
  	CACHE MANIFEST
  	#v0.11
  	CACHE:
  	js/app.js
  	css/style.css
  	NETWORK:
  	resourse/logo.png
  	FALLBACK:
  	/ /offline.html
  3、在离线状态时，操作window.applicationCache进行需求实现。
```

## CSS

- 请介绍下float的表现，什么情况下适用。

```doc
浮动（float）是 CSS 定位属性。浮动元素从网页的正常流动中移出，但是保持了部分的流动性，会影响其他元素的定位（比如文字会围绕着浮动元素）。这一点与绝对定位不同，绝对定位的元素完全从文档流中脱离。

CSS 的clear属性通过使用left、right、both，让该元素向下移动（清除浮动）到浮动元素下面。

如果父元素只包含浮动元素，那么该父元素的高度将塌缩为 0。我们可以通过清除（clear）从浮动元素后到父元素关闭前之间的浮动来修复这个问题。

有一种 hack 的方法，是自定义一个.clearfix类，利用伪元素选择器::after清除浮动。另外还有一些方法，比如添加空的<div></div>和设置浮动元素父元素的overflow属性。与这些方法不同的是，clearfix方法，只需要给父元素添加一个类，定义如下：
```

- margin和padding分别适合什么场景使用？

```doc
  margin是用来隔开元素与元素的间距；padding是用来隔开元素与内容的间隔。
  margin用于布局分开元素使元素与元素互不相干；
  padding用于元素与内容之间的间隔，让内容（文字）与（包裹）元素之间有一段
```

- ::before 和 :after中双冒号和单冒号 有什么区别？解释一下这2个伪元素的作用。

```doc
  单冒号(:)用于CSS3伪类，双冒号(::)用于CSS3伪元素。（伪元素由双冒号和伪元素名称组成）
  双冒号是在当前规范中引入的，用于区分伪类和伪元素。不过浏览器需要同时支持旧的已经存在的伪元素写法，
  比如:first-line、:first-letter、:before、:after等，
  而新的在CSS3中引入的伪元素则不允许再支持旧的单冒号的写法。

  想让插入的内容出现在其它内容前，使用::before，否者，使用::after；
  在代码顺序上，::after生成的内容也比::before生成的内容靠后。
  如果按堆栈视角，::after生成的内容会在::before生成的内容之上
```

- 设置元素浮动后，该元素的display值是多少？

```doc
  自动变成了 display:block
```

- 如果需要手动写动画，你认为最小时间间隔是多久，为什么？

```doc
 多数显示器默认频率是60Hz，即1秒刷新60次，所以理论上最小间隔为1/60＊1000ms ＝ 16.7ms
```

- display:inline-block 怎么清除间隙？

```doc
移除空格、使用margin负值、使用font-size:0、letter-spacing、word-spacing
```

- png、jpg、gif 这些图片格式解释一下，分别什么时候用。有没有了解过webp？

```doc
1、gif图形交换格式，索引颜色格式，颜色少的情况下，产生的文件极小，支持背景透明，动画，图形渐进，无损压缩（适合线条，图标等），缺点只有256种颜色。透明图会有白色毛边
2、jpg支持上百万种颜色，有损压缩，压缩比可达180：1，而且质量受损不明显，不支持图形渐进与背景透明，不支持动画
3、Png8简单说是静态gif，png24颜色更加丰富,文件更大。无白色毛边
4、webp谷歌开发的旨在加快图片加载速度的图片格式，图片压缩体积是jpeg的2/3，有损压缩。高版本的W3C浏览器才支持，google39+，safari7+
```

- 什么是Cookie 隔离？（或者说：请求资源的时候不要让它带cookie怎么做）

```doc
  如果静态文件都放在主域名下，那静态文件请求的时候都带有的cookie的数据提交给server的，非常浪费流量，
  所以不如隔离开。

  因为cookie有域的限制，因此不能跨域提交请求，故使用非主要域名的时候，请求头中就不会带有cookie数据，
  这样可以降低请求头的大小，降低请求时间，从而达到降低整体请求延时的目的。

  同时这种方式不会将cookie传入Web Server，也减少了Web Server对cookie的处理分析环节，
  提高了webserver的http请求的解析速度。
```

- 什么是物理像素，逻辑像素。

```doc
物理像素（分辨率）是指设备屏幕实际拥有的像素点。比如iPhone 6的屏幕在宽度方向有750个像素点，高度方向有1334个像素点，所以iPhone 6 总共有750*1334个物理像素。
逻辑像素(又称设备无关像素 Device Independent Pixels），可以认为是计算机坐标系统中得一个点,这个点代表一个可以由程序使用的虚拟像素(比如: css像素),然后由相关系统转换为物理像素。

```

- 介绍下单位px，pt，em，rem，vw。

```doc
px：(pixel)像素，像素px是相对于显示器屏幕分辨率而言的(引自CSS2.0手册)。电子屏幕上组成一幅图画或照片的最基本单元；
pt: (point)点，印刷行业常用单位，等于1/72英寸，就是我们在Word或者WPS等办公软件中使用的字体大小单位；
em:(emphasize) 是相对长度单位，相对于当前对象内文本的字体尺寸，即em的计算是基于父级元素font-size的；
rem: （root em，根em）是css3新增的一个相对单位，与em的区别在于，它是相对于html根元素的(在body标签里面设置字体大小不起作用)；
vw：viewpoint width，视窗宽度，1vw等于视窗宽度的1%。
```

- 如何实现事件监听类或函数

```doc
	// event(事件)工具集，来源：github.com/markyun
 	markyun.Event = {
 		// 页面加载完成后
 		readyEvent : function(fn) {
 			if (fn==null) {
 				fn=document;
 			}
 			var oldonload = window.onload;
 			if (typeof window.onload != 'function') {
 				window.onload = fn;
 			} else {
 				window.onload = function() {
 					oldonload();
 					fn();
 				};
 			}
 		},
 		// 视能力分别使用dom0||dom2||IE方式 来绑定事件
 		// 参数： 操作的元素,事件名称 ,事件处理程序
 		addEvent : function(element, type, handler) {
 			if (element.addEventListener) {
 				//事件类型、需要执行的函数、是否捕捉
 				element.addEventListener(type, handler, false);
 			} else if (element.attachEvent) {
 				element.attachEvent('on' + type, function() {
 					handler.call(element);
 				});
 			} else {
 				element['on' + type] = handler;
 			}
 		},
 		// 移除事件
 		removeEvent : function(element, type, handler) {
 			if (element.removeEventListener) {
 				element.removeEventListener(type, handler, false);
 			} else if (element.datachEvent) {
 				element.detachEvent('on' + type, handler);
 			} else {
 				element['on' + type] = null;
 			}
 		},
 		// 阻止事件 (主要是事件冒泡，因为IE不支持事件捕获)
 		stopPropagation : function(ev) {
 			if (ev.stopPropagation) {
 				ev.stopPropagation();
 			} else {
 				ev.cancelBubble = true;
 			}
 		},
 		// 取消事件的默认行为
 		preventDefault : function(event) {
 			if (event.preventDefault) {
 				event.preventDefault();
 			} else {
 				event.returnValue = false;
 			}
 		},
 		// 获取事件目标
 		getTarget : function(event) {
 			return event.target || event.srcElement;
 		},
 		// 获取event对象的引用，取到事件的所有信息，确保随时能使用event；
 		getEvent : function(e) {
 			var ev = e || window.event;
 			if (!ev) {
 				var c = this.getEvent.caller;
 				while (c) {
 					ev = c.arguments[0];
 					if (ev && Event == ev.constructor) {
 						break;
 					}
 					c = c.caller;
 				}
 			}
 			return ev;
 		}
 	};
```

- 什么是闭包（closure），闭包有什么坏处？

```doc
闭包是指有权访问另一个函数作用域中变量的函数，创建闭包的最常见的方式就是在一个函数内创建另一个函数，通过另一个函数访问这个函数的局部变量,利用闭包可以突破作用链域，将函数内部的变量和方法传递到外部。

闭包没有坏处。闭包只是一种编码方式。不会造成内存泄露。
```

- 那些操作会造成内存泄漏？或者介绍下你知道的内存回收机制。

```doc
标记清除：  
js中最常用的垃圾回收方式就是标记清除。当变量进入环境时，例如，在一个函数中声明一个变量，就将这个变量标记为"进入环境"，从逻辑上讲，永远不能释放进入环境变量所占用的内存，因为只要执行流进入相应的环境，就可能会用到它们。而当变量离开环境时，则将其标记为"离开环境"。
引用计数：  
语言引擎有一张"引用表"，保存了内存里面所有资源（通常是各种值）的引用次数。如果一个值的引用次数是0，就表示这个值不再用到了，因此可以将这块内存释放。


如果变量存在于全局就不会被回收。某个页面长时间的运行。window重复绑定某个事件。
或react vue 组件销毁忘记销毁百度地图对象。也会造成内存泄露。
```

- WEB应用从服务器主动推送Data到客户端有那些方式？

```doc
  html5提供的Websocket
  SSE
  连接长时间挂起。超时。
```

- 高阶函数（higher-order）的定义是什么？

```doc
高阶函数是将一个或多个函数作为参数的函数，它用于数据处理，也可能将函数作为返回结果。高阶函数是为了抽象一些重复执行的操作。一个典型的例子是map，它将一个数组和一个函数作为参数。map使用这个函数来转换数组中的每个元素，并返回一个包含转换后元素的新数组。JavaScript 中的其他常见示例是forEach、filter和reduce。高阶函数不仅需要操作数组的时候会用到，还有许多函数返回新函数的用例。Function.prototype.bind就是一个例子。
```

- 你能举出一个柯里化函数（curry function）的例子吗？它有哪些好处？

```doc
柯里化（currying）是一种模式，其中具有多个参数的函数被分解为多个函数，当被串联调用时，将一次一个地累积所有需要的参数。这种技术帮助编写函数式风格的代码，使代码更易读、紧凑。值得注意的是，对于需要被 curry 的函数，它需要从一个函数开始，然后分解成一系列函数，每个函数都需要一个参数。
```

- 说说你对 AMD 和 CommonJS 的了解。

```doc
它们都是实现模块体系的方式，直到 ES2015 出现之前，JavaScript 一直没有模块体系。CommonJS 是同步的，而 AMD（Asynchronous Module Definition）从全称中可以明显看出是异步的。CommonJS 的设计是为服务器端开发考虑的，而 AMD 支持异步加载模块，更适合浏览器。

我发现 AMD 的语法非常冗长，CommonJS 更接近其他语言 import 声明语句的用法习惯。大多数情况下，我认为 AMD 没有使用的必要，因为如果把所有 JavaScript 都捆绑进一个文件中，将无法得到异步加载的好处。此外，CommonJS 语法上更接近 Node 编写模块的风格，在前后端都使用 JavaScript 开发之间进行切换时，语境的切换开销较小。

我很高兴看到 ES2015 的模块加载方案同时支持同步和异步，我们终于可以只使用一种方案了。虽然它尚未在浏览器和 Node 中完全推出，但是我们可以使用代码转换工具进行转换。
```

- GET和POST的区别

```doc
GET 和 POST 方法没有实质区别，只是报文格式不同。

有一下误解  
get url 长度限制是某些浏览器和服务器的限制，和 HTTP 协议没有关系
POST 方法比 GET 方法安全？ 都是http明文发送地址和参数都是可见的没区别
GET 方法参数写法是固定的吗？ get也可以写body
```

- 说一下宏任务和微任务？

```doc
宏任务：当前调用栈中执行的任务称为宏任务。（主代码块，定时器等等）。  
微任务： 当前（此次事件循环中）宏任务执行完，在下一个宏任务开始之前需要执行的任务为微任务。（可以理解为回调事件，promise.then，process.nextTick等等）。  
宏任务中的事件放在callback queue中，由事件触发线程维护；微任务的事件放在微任务队列中，由js引擎线程维护。

```

## 其他问题

- 介绍下 RESTFUL

```doc
REST（英文：Representational State Transfer，简称
REST）描述了一个架构样式的网络系统，比如 web 应用程序。它首次出现在 2000 年 Roy Fielding 的博士论文中，Roy Fielding是 HTTP 规范的主要编写者之一。在目前主流的三种Web服务交互方案中，REST相比于SOAP（Simple Object Access protocol，简单对象访问协议）以及XML-RPC更加简单明了，无论是对URL的处理还是对Payload的编码，REST都倾向于用更加简单轻量的方法设计和实现。值得注意的是REST并没有一个明确的标准，而更像是一种设计的风格。

Rest架构的主要原则
** 网络上的所有事物都被抽象为资源**

** 每个资源都有一个唯一的资源标识符**

** 同一个资源具有多种表现形式(xml,json等)**

** 对资源的各种操作不会改变资源标识符**

** 所有的操作都是无状态的**

** 符合REST原则的架构方式即可称为RESTful**

```

- 介绍下公钥加密和私钥加密。

```doc
  一般情况下是指私钥用于对数据进行签名，公钥用于对签名进行验证;
  HTTP网站在浏览器端用公钥加密敏感数据，然后在服务器端再用私钥解密。
```

- 一个页面从输入 URL 到页面加载显示完成，这个过程中都发生了什么？（流程说的越详细越好）

```doc
  注：这题胜在区分度高，知识点覆盖广，再不懂的人，也能答出几句，
    而高手可以根据自己擅长的领域自由发挥，从URL规范、HTTP协议、DNS、CDN、数据库查询、
    到浏览器流式解析、CSS规则构建、layout、paint、onload/domready、JS执行、JS API绑定等等；

    详细版：
  	1、浏览器会开启一个线程来处理这个请求，对 URL 分析判断如果是 http 协议就按照 Web 方式来处理;
  	2、调用浏览器内核中的对应方法，比如 WebView 中的 loadUrl 方法;
      3、通过DNS解析获取网址的IP地址，设置 UA 等信息发出第二个GET请求;
  	4、进行HTTP协议会话，客户端发送报头(请求报头);
      5、进入到web服务器上的 Web Server，如 Apache、Tomcat、Node.JS 等服务器;
      6、进入部署好的后端应用，如 PHP、Java、JavaScript、Python 等，找到对应的请求处理;
  	7、处理结束回馈报头，此处如果浏览器访问过，缓存上有对应资源，会与服务器最后修改时间对比，一致则返回304;
      8、浏览器开始下载html文档(响应报头，状态码200)，同时使用缓存;
      9、文档树建立，根据标记请求所需指定MIME类型的文件（比如css、js）,同时设置了cookie;
      10、页面开始渲染DOM，JS根据DOM API操作DOM,执行事件绑定等，页面显示完成。

    简洁版：
  	浏览器根据请求的URL交给DNS域名解析，找到真实IP，向服务器发起请求；
  	服务器交给后台处理完成后返回数据，浏览器接收文件（HTML、JS、CSS、图象等）；
  	浏览器对加载到的资源（HTML、JS、CSS等）进行语法解析，建立相应的内部数据结构（如HTML的DOM）；
  	载入解析到的资源文件，渲染页面，完成。
```

- 你怎么看待Web App 、hybrid App、Native App？

- 产品进行版本升级时，可能发生不兼容性问题，如何提前预防和解决？

```doc
  开闭原则
  非覆盖式发布，API新增而不是在原来的上面修改；
  提前做好 @Deprecated的版本提示；
```

- 是否了解Web注入攻击，说下原理，最常见的两种攻击（XSS 和 CSRF）了解到什么程度？

```doc
xss: 跨站脚本攻击（Cross Site Scripting）是最常见和基本的攻击 WEB 网站方法，攻击者通过注入非法的 html 标签或者 javascript 代码，从而当用户浏览该网页时，控制用户浏览器。
csrf：跨站点请求伪造（Cross-Site Request Forgeries），也被称为 one-click attack 或者 session riding。冒充用户发起请求（在用户不知情的情况下）， 完成一些违背用户意愿的事情（如修改用户信息，删初评论等）。
```

- 对前端安全有什么看法？ 
[详解](https://github.com/unclemake/blog-1)

- 对前端工程化有什么看法？
[详解](https://github.com/fouber/blog/issues/3)

- 是否了解开源的工具 bower、npm、yeoman、grunt、gulp，有无用过，有无写过

- 一个 npm 的包里的 package.json 了解的字段都有哪些。
[详解](https://www.jianshu.com/p/b3d86ddfd555)

- MVC，MVP 和 MVVM 介绍下
[详解](http://www.ruanyifeng.com/blog/2015/02/mvcmvp_mvvm.html)

## Vue

- vuex原理
[详解](https://zhuanlan.zhihu.com/p/78981485)

## React

- 介绍一下redux？

```doc
redux 是一个应用数据流框架，主要是解决了组件间状态共享的问题，主要包括三个核心方法，action，store，reducer

关于 Store：

整个应用只有一个唯一的 Store
Store 对应的状态树（State），由调用一个 reducer 函数（root reducer）生成
状态树上的每个字段都可以进一步由不同的 reducer 函数生成
Store 包含了几个方法比如 dispatch, getState 来处理数据流
Store 的状态树只能由 dispatch(action) 来触发更改
Redux 的数据流：

action 是一个包含 { type, payload } 的对象
reducer 函数通过 store.dispatch(action) 触发
reducer 函数接受 (state, action) 两个参数，返回一个新的 state
reducer 函数判断 action.type 然后处理对应的 action.payload 数据来更新状态树
所以对于整个应用来说，一个 Store 就对应一个 UI 快照，服务器端渲染就简化成了在服务器端初始化 Store，将 Store 传入应用的根组件，针对根组件调用 renderToString 就将整个应用输出成包含了初始化数据的 HTML。

```

- 当您调用setState的时候，发生了什么事？

```doc
当调用 setState 时，React会做的第一件事情是将传递给 setState 的对象合并到组件的当前状态。这将启动一个称为和解（reconciliation）的过程。和解（reconciliation）的最终目标是以最有效的方式，根据这个新的状态来更新UI。 为此，React将构建一个新的 React 元素树（您可以将其视为 UI 的对象表示）。
一旦有了这个树，为了弄清 UI 如何响应新的状态而改变，React 会将这个新树与上一个元素树相比较（ diff ）。
通过这样做， React 将会知道发生的确切变化，并且通过了解发生什么变化，只需在绝对必要的情况下进行更新即可最小化 UI 的占用空间
```

- 介绍下不可变数据Immutability 。

```doc
更改数据的两种方式：
1、直接更改变量；
2、建立所需修改变量的副本，进行修改后替换原数据。
不直接改变数据的好处
1、可以帮助我们增强组件和整体应用性能。
2、更简单的撤消/重做和步骤重现
3、不可变数据（Immutability）还使一些复杂的功能更容易实现。避免数据改变，使我们能够保留对旧数据的引用，如果我们需要在它们之间切换。
4、追踪变更（Tracking Changes）
确定可变对象是否已更改是复杂的，因为直接对对象进行更改。这样就需要将当前对象与先前的副本进行比较，遍历整个对象树，并比较每个变量和值。这个过程可能变得越来越复杂。确定不可变对象如何改变是非常容易的。如果被引用的对象与之前不同，那么对象已经改变了。仅此而已。
5、确定何时重新渲染（Determining When to Re-render in React）
React 中不可变数据最大好处在于当您构建简单的 纯(pure)组件 时。由于不可变数据可以更容易地确定是否已经进行了更改，这也有助于确定组件何时需要重新渲染。
与shouldComponentUpdate()相关
```

- 简述 flux 思想

```doc
Flux 的最大特点，就是数据的"单向流动"。

用户访问 View
View 发出用户的 Action
Dispatcher 收到 Action，要求 Store 进行相应的更新
Store 更新后，发出一个"change"事件
View 收到"change"事件后，更新页面
```

- React中的合成事件是什么？

```doc
如果DOM上绑定了过多的事件处理函数，整个页面响应以及内存占用可能都会受到影响。React为了避免这类DOM事件滥用，同时屏蔽底层不同浏览器之间的事件系统差异，实现了一个中间层——SyntheticEvent。

当用户在为onClick添加函数时，React并没有将Click时间绑定在DOM上面。
而是在document处监听所有支持的事件，当事件发生并冒泡至document处时，React将事件内容封装交给中间层SyntheticEvent（负责所有事件合成）
所以当事件触发的时候，对使用统一的分发函数dispatchEvent将指定函数执行。
```

- react如何进行性能优化

```doc
function component + redux、immutable、pure component , shouldComponentUpdate
直接操作dom元素state记录数据
```

- 介绍下了解的设计模式

```doc
设计模式
1、创建型模式：
1单例模式、Singletion 
2抽象工厂模式、Abstract Factory 
3建造者模式、Builder 
4工厂模式、Factory 
5原型模式。Prototype

2、结构型模式：
6适配器模式、Adapter 
7桥接模式、Bridge 
8装饰模式、Decorator 
9组合模式、Composite 
10外观模式、Facade 
11享元模式、Flyweight 
12代理模式。Proxy

3、行为型模式：
13模版方法模式、Template Method 
14命令模式、Command 
15迭代器模式、Iterator 
16观察者模式、Observer 
17中介者模式、Mediator 
18备忘录模式、Memento 
19解释器模式、Interpreter 
20状态模式、State 
21策略模式、Strategy 
22职责链模式、Chain of Responsibility 
23访问者模式。Visitor
```

- 介绍下设计原则

```doc
1、开闭原则（Open Close Principle）
开闭原则就是说对扩展开放，对修改关闭。在程序需要进行拓展的时候，不能去修改原有的代码，实现一个热插拔的效果。所以一句话概括就是：为了使程序的扩展性好，易于维护和升级。想要达到这样的效果，我们需要使用接口和抽象类，后面的具体设计中我们会提到这点。

2、里氏代换原则（Liskov Substitution Principle）
里氏代换原则(Liskov Substitution Principle LSP)面向对象设计的基本原则之一。 
里氏代换原则中说，任何基类可以出现的地方，子类一定可以出现。 LSP是继承复用的基石，只有当衍生类可以替换掉基类，软件单位的功能不受到影响时，基类才能真正被复用，而衍生类也能够在基类的基础上增加新的行为。里 氏代换原则是对“开-闭”原则的补充。实现“开-闭”原则的关键步骤就是抽象化。而基类与子类的继承关系就是抽象化的具体实现，所以里氏代换原则是对实现 抽象化的具体步骤的规范。

3、依赖倒转原则（Dependence Inversion Principle）
这个是开闭原则的基础，具体内容：针对接口编程，依赖于抽象而不依赖于具体。

4、接口隔离原则（Interface Segregation Principle）
这个原则的意思是：使用多个隔离的接口，比使用单个接口要好。还是一个降低类之间的耦合度的意思，从这儿我们看出，其实设计模式就是一个软件的设计思想，从大型软件架构出发，为了升级和维护方便。所以上文中多次出现：降低依赖，降低耦合。

5、迪米特法则（最少知道原则）（Demeter Principle）
为什么叫最少知道原则，就是说：一个实体应当尽量少的与其他实体之间发生相互作用，使得系统功能模块相对独立。

6、合成复用原则（Composite Reuse Principle）
原则是尽量使用合成/聚合的方式，而不是使用继承。
```

- 什么是函数式编程思维
[详解](https://www.zhihu.com/question/28292740/answer/40336090)

- 邮箱简单的正则表达式怎么写

```doc
^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$
```

- 你是如何进行项目框架选型

```doc
性能，学习成本，热度，发展
```

- 说说你对webpack的理解

```doc
是一个模块打包工具，你可以使用 WebPack
管理你的模块依赖，并编绎输出模块们所需的静态文件。它能够很好地管理、打包Web开发中所用到的 HTML、JavaScript、CSS
以及各种静态文件（图片、字体等），让开发过程更加高效。对于不同类型的资源， webpack
有对应的模块加载器。 webpack
模块打包器会分析模块间的依赖关系，最后 生成了优化且合并后的静态资源。
```

- 你知道几种排序算法，那种排序算法比较快。

```doc
冒泡排序
简单选择排序
直接插入排序
希尔排序
堆排序
归并排序
快速排序

从数据排序前的有序情况来分
已经有序，近乎有序，基本无序等
不同的数据分布情况下，快速排序的时间复杂度，平均表现都不差吧。
从工程实现的角度来看，排序算法都是结合了多种排序方法的。
sort，是通过 先快排，递归深度超过一个阀值就改成堆排，然后对最后的几个进行插入排序来实现的。
```
