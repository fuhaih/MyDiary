# T1考题

## HTML

- 行内元素有哪些？块级元素有哪些？ 空(void)元素有那些？

```doc
首先：CSS规范规定，每个元素都有display属性，确定该元素的类型，每个元素都有默认的display值，如div的display默认值为“block”，则为“块级”元素；span默认display属性值为“inline”，是“行内”元素。

  （1）行内元素有：a b span img input select strong（强调的语气）
  （2）块级元素有：div ul ol li dl dt dd h1 h2 h3 h4…p

  （3）常见的空元素：
    <br> <hr> <img> <input> <link> <meta>  
    鲜为人知的是：  
    <area> <base> <col> <command> <embed> <keygen> <param> <source> <track> <wbr>

  不同浏览器（版本）、HTML4（5）、CSS2等实际略有差异
```

- 页面导入样式时，使用link和@import有什么区别？

```doc
  （1）link属于XHTML标签，除了加载CSS外，还能用于定义RSS, 定义rel连接属性等作用；而@import是CSS提供的，只能用于加载CSS;

  （2）页面被加载的时，link会同时被加载，而@import引用的CSS会等到页面被加载完再加载;

  （3）import是CSS2.1 提出的，只在IE5以上才能被识别，而link是XHTML标签，无兼容问题;
   (4)link支持使用js控制DOM去改变样式，而@import不支持;
```

- Label的作用是什么？是怎么用的？

```doc
  label标签来定义表单控制间的关系,当用户选择该标签时，浏览器会自动将焦点转到和标签相关的表单控件上。

  <label for="Name">Number:</label>
  <input type=“text“name="Name" id="Name"/>

  <label>Date:<input type="text" name="B"/></label>
```

## CSS

- 介绍一下标准的CSS的盒子模型？低版本IE的盒子模型有什么不同的？

```doc
  （1）有两种， IE 盒子模型、W3C 盒子模型；
  （2）盒模型： 内容(content)、填充(padding)、边界(margin)、 边框(border)；
  （3）区  别： IE的content部分把 border 和 padding计算了进去;
```

- CSS选择符有哪些？哪些属性可以继承？

```doc
  *   1.id选择器（ # myid）
  	2.类选择器（.myclassname）
  	3.标签选择器（div, h1, p）
  	4.相邻选择器（h1 + p）
  	5.子选择器（ul > li）
  	6.后代选择器（li a）
  	7.通配符选择器（ * ）
  	8.属性选择器（a[rel = "external"]）
  	9.伪类选择器（a:hover, li:nth-child）

  *   可继承的样式： font-size font-family color, UL LI DL DD DT;

  *   不可继承的样式：border padding margin width height ;
```

- 如何用css实现一个三角形？

```doc
  border-color:#FF9600 transparent transparent transparent;
  border-style:solid;
  border-width:20px;
```

- display有哪些值？说明他们的作用。

```doc
    block       	块类型。默认宽度为父元素宽度，可设置宽高，换行显示。
    none        	元素不显示，并从文档流中移除。
    inline      	行内元素类型。默认宽度为内容宽度，不可设置宽高，同行显示。
    inline-block    默认宽度为内容宽度，可以设置宽高，同行显示。
    list-item   	象块类型元素一样显示，并添加样式列表标记。
    table       	此元素会作为块级表格来显示。
    inherit     	规定应该从父元素继承 display 属性的值。
    flex            flex布局
```

- 介绍下position

```doc
1、position:relative：	
相对定位，作为是一个标识，可以使用left,right,top,bottom修改位置
2、position:absolute	
绝对定位，根据父级定位（relative, absolute, fixed）来决定位置，可以使用left,right,top,bottom修改位置
3、position:fixed
固定定位，一旦固定在页面上就不会再移动位置，可以使用left,right,top,bottom修改位置
4、postion:static 静态定位，无效果，可以用来清除以前的定位	
5、position: sticky;设置了sticky的元素，在屏幕范围内（viewport）的时候，该元素并不受到定位的影响（设置是top,left等的属性是无效的）当这个元素要移除便宜范围内的时候定位又会变成filexd,然后根据op,left等的属性固定位置的效果 
```

- 什么是外边距合并？

```doc
  外边距合并指的是，当两个垂直外边距相遇时，它们将形成一个外边距。
  合并后的外边距的高度等于两个发生合并的外边距的高度中的较大者。
```

- 介绍下flex布局
[详解](http://www.ruanyifeng.com/blog/2015/07/flex-grammar.html?utm_source=tuicool)

- Display:none与visibility;hidden的区别是什么？

```doc
1、display:none 内容隐藏，不占据页面空间
2、visibility:hidden 内容隐藏，占居页面空间
```

- 介绍一下CSS的盒子模型？

```doc
外边距 -> 边框 -> 内边距 -> 内容, content-box ，border-box
```

- 什么是事件冒泡和事件捕获和事件委托？

```doc
事件捕获是指事件会从开始发生，直到最具体的元素。而事件冒泡正好相反，事件冒泡是指事件会从最内层的元素开始发生，一直向外传播
事件委托是指将事件绑定在父元素上，然后采用事件冒泡的方法，当事件流达到父元素时，可以通过target获取真正触发的当前元素，并执行绑定在父元素上的方法
```

- 如何解决浮点数运算问题？

```doc
.toFixed(2)
直接使用数学框架。
常见错误
0.007 * 100  =  7.00000000000001 所以转成整数是不完全正确答案。
```

## JS

- 介绍js的基本数据类型。

```doc
 Undefined、Null、Boolean、Number、String、
 ECMAScript 2015 新增:Symbol(创建后独一无二且不可变的数据类型 )
```

- 介绍js有哪些内置对象？

```doc
 Object 是 JavaScript 中所有对象的父对象

 数据封装类对象：Object、Array、Boolean、Number 和 String
 其他对象：Function、Arguments、Math、Date、RegExp、Error
```

- 如何将字符串转化为数字?

```doc
  parseFloat('12.3')
  parseInt('12.3')
  Number('12.3')
```

- null，undefined 的区别？

```doc
 null 		表示一个对象是“没有值”的值，也就是值为“空”；
 undefined 	表示一个变量声明了没有初始化(赋值)；
```

- “ ===”、“ ==”的区别？

```doc
两等号判等，会在比较时进行类型转换；
三等号判等(判断严格)，比较时不进行隐式类型转换,（类型不同则会返回false）；
```

- 已知ID的Input输入框，希望获取这个输入框的输入值，怎么做？

```doc
document.getElementById("ID").value
```

- Javascript的事件流模型都有什么？

```doc
“事件冒泡”：事件开始由最具体的元素接受，然后逐级向上传播
“事件捕捉”：事件由最不具体的节点先接收，然后逐级向下，一直到最具体的
“DOM事件流”：三个阶段：事件捕捉，目标阶段，事件冒泡
```

- 怎样添加、移除、移动、复制、创建和查找节点（原生JS，实在基础，没细写每一步）

```doc
1）创建新节点

createDocumentFragment() //创建一个DOM片段
createElement() //创建一个具体的元素
createTextNode() //创建一个文本节点

2）添加、移除、替换、插入

appendChild() //添加
removeChild() //移除
replaceChild() //替换
insertBefore() //插入

3）查找

getElementsByTagName() //通过标签名称
getElementsByName() //通过元素的Name属性的值
getElementById() //通过元素Id，唯一性
```

- 写一个function，清除字符串前后的空格

```doc
if (!String.prototype.trim) {
 String.prototype.trim = function() {
    return this.replace(/^\s+/, "").replace(/\s+$/,"");
 }
}

// test the function
var str = " \t\n test string ".trim();
alert(str == "test string"); // alerts "true"
```

- 把两个数组合并，并删除第二个元素。

```doc
var array1 = ['a','b','c'];
var bArray = ['d','e','f'];
var cArray = array1.concat(bArray);
cArray.splice(1,1);
```

- 数组方法pop() push() unshift() shift()

```doc
push()尾部添加 pop()尾部删除
unshift()头部添加 shift()头部删除
```

## 其他问题

- 介绍下git，说上来几个命令，说一下git和svn的区别，git如何解决冲突。

### Vue

- 写出至少4种vue当中的指令和它的用法？

```doc
v-once: 只绑定一次
v-bind: 绑定数据
v-model: 绑定模型
v-on: 绑定事件
v-if v-show: 条件渲染
```

- 怎么定义vue-router的动态路由？怎么获取传过来的动态参数？ 

```doc
在router目录下的index.js文件中，对path属性加上/:id。  使用router对象的params.id
```

- vuex有哪几种状态和属性？

```doc
有五种,分别是State , Getter , Mutation , Action , Module 
```

- vue怎么引入组件

```doc
全局注册
import Users from "@/components/Users.vue";
Vue.component('Users',Users)

局部引入
import Users from "@/components/Users.vue";
export default {
  name: "App",
  data: function() {
    return {    
  },
  //注册组件
  components: {
    Users,
  }
};
```

- Vue的生命周期

```doc
beforeCreate（创建前） 在数据观测和初始化事件还未开始
created（创建后） 完成数据观测，属性和方法的运算，初始化事件，$el属性还没有显示出来
beforeMount（载入前） 在挂载开始之前被调用，相关的render函数首次被调用。实例已完成以下的配置：编译模板，把data里面的数据和模板生成html。注意此时还没有挂载html到页面上。
mounted（载入后） 在el 被新创建的 vm.$el 替换，并挂载到实例上去之后调用。实例已完成以下的配置：用上面编译好的html内容替换el属性指向的DOM对象。完成模板中的html渲染到html页面中。此过程中进行ajax交互。
beforeUpdate（更新前） 在数据更新之前调用，发生在虚拟DOM重新渲染和打补丁之前。可以在该钩子中进一步地更改状态，不会触发附加的重渲染过程。
updated（更新后） 在由于数据更改导致的虚拟DOM重新渲染和打补丁之后调用。调用时，组件DOM已经更新，所以可以执行依赖于DOM的操作。然而在大多数情况下，应该避免在此期间更改状态，因为这可能会导致更新无限循环。该钩子在服务器端渲染期间不被调用。
beforeDestroy（销毁前） 在实例销毁之前调用。实例仍然完全可用。
destroyed（销毁后） 在实例销毁之后调用。调用后，所有的事件监听器会被移除，所有的子实例也会被销毁。该钩子在服务器端渲染期间不被调用。
```

- css只在当前组件起作用

```doc
在style标签中写入scoped即可 例如：<style scoped></style>
```

- v-if 和 v-show 区别

```doc
v-if按照条件是否渲染，v-show是display的block或none；
```

## React

- React 中 refs 的作用是什么？

```doc
Refs是React提供给我们安全的访问DOM元素或者某个组件实例的句柄,我们可以为元素添加ref属性然后在回调函数中接收该元素在DOM树中的句柄,该值会作为回调函数的第一个参数的返回
```

- React 中 更新视图的方式有几种？

```doc
this.setState
ref 直接修改dom对象
redux 类框架
```

- React 中 map循环key的作用是什么？

```doc
key 帮助 React 识别哪些元素改变了，比如被添加或删除。因此你应当给数组中的每一个元素赋予一个确定的标识。
```

- 父传子，子传父数据传递方式？

```doc
父传子 props
子传父 props 函数
或 全局变量  
```

## jquery

jquery隐藏一个元素。删除一个元素

```doc
hide()  remove() 直接操作css
```

你要是在一个 jQuery 事件处理程序里返回了 false 会怎样？

```doc
这通常用于阻止事件向上冒泡。
```

如何获取父级元素，祖先的函数有哪几个。

```doc

$("#id").parent() 方法返回被选元素的直接父元素。  

$("#id").parents('.xx') 沿 DOM 树向上遍历，直到文档的根元素为止，将每个祖先元素添加到一个临时的集合；如果应用了选择器，则会基于该选择器对这个集合进行筛选 	返回包含零个、一个或多个元素的 jQuery 对象

$("#id").closest('.xx) 沿 DOM 树向上遍历，直到找到已应用选择器的一个匹配为止。 返回包含零个或一个元素的 jQuery 对象
```

jquery get 如何清理缓存？

```doc
 在提交时加上时间戮
 $.ajaxSetup({ cache: false });
```

jquery 同胞元素的获取函数有哪些

```doc
siblings()
next()
nextAll()
nextUntil()
prev()
prevAll()
prevUntil()
```

